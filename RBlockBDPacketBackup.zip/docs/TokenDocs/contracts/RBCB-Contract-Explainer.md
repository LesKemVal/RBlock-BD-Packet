# RBCB Contract Explainer

This document will explain the terms and mechanics of the RBCB smart contract used in the R. Block token issuance.

*Coming soon.*

