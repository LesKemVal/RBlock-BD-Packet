# EIN Summary – IRS Confirmation

## Federal Tax Info

- **Employer Identification Number (EIN):** 33-4657277
- **Issued By:** U.S. Internal Revenue Service (IRS)
- **Use Case:** Tax identification for Reg CF filings, banking, and compliance integrations

> Full EIN confirmation letter available on request for funding portal or escrow partners.

